<?php
define('EMAIL_HOST', 'smtp.qq.com');
define('EMAIL_PORT', 587);
define('EMAIL_USER', 'your_email@qq.com');
define('EMAIL_PASS', 'your_auth_code'); // QQ邮箱授权码
define('EMAIL_FROM', 'your_email@qq.com');
define('EMAIL_FROM_NAME', 'Game Store');
?>