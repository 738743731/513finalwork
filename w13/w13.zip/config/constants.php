<?php
define('SITE_NAME', 'GameHub');
define('SITE_URL', 'http://localhost/game_store/');
define('SESSION_TIMEOUT', 3600); // 1小时
?>